﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace MarkdownGdi;

public static class MarkdownParser
{
    private static readonly Regex HeadingRegex = new(@"^\s*(#{1,6})\s+(.+?)\s*$", RegexOptions.Compiled);
    private static readonly Regex QuoteRegex = new(@"^\s*>\s?.*$", RegexOptions.Compiled);
    private static readonly Regex FenceStartRegex = new(@"^\s*(```+|~~~+)\s*(.*)$", RegexOptions.Compiled);

    // Horizontal Rule: ---  ***  ___  (auch mit Spaces dazwischen)
    // Bis zu 3 führende Spaces wie bei Markdown üblich.
    private static readonly Regex HorizontalRuleRegex =
        new(@"^\s{0,3}(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})\s*$", RegexOptions.Compiled);

    // Gültige Delimiter-Zelle: ---  :---  ---:  :---: (mind. 3 Bindestriche)
    private static readonly Regex TableDelimiterCellRegex = new(@"^:?-{3,}:?$", RegexOptions.Compiled);

    // List line:
    // indent + (unordered marker OR ordered number.) + at least one whitespace + text (can be empty/space)
    // Beispiele:
    // "- a", "  * b", "    + c", "1. x", "  42. y"
    private static readonly Regex ListLineRegex = new(
        @"^(?<indent>[ \t]*)(?:(?<ul>[-+*])|(?<num>\d+)\.)(?<ws>[ \t]+)(?<text>.*)$",
        RegexOptions.Compiled);

    public static IReadOnlyList<MarkdownBlock> Parse(IReadOnlyList<string> lines)
    {
        var blocks = new List<MarkdownBlock>();
        int i = 0;

        while (i < lines.Count)
        {
            string line = lines[i];

            if (string.IsNullOrWhiteSpace(line))
            {
                blocks.Add(new BlankBlock(i));
                i++;
                continue;
            }

            if (TryParseFencedCode(lines, ref i, out var code))
            {
                blocks.Add(code);
                continue;
            }

            if (TryParseTable(lines, ref i, out var table))
            {
                blocks.Add(table);
                continue;
            }

            var hm = HeadingRegex.Match(line);
            if (hm.Success)
            {
                int level = hm.Groups[1].Value.Length;
                string text = hm.Groups[2].Value;
                blocks.Add(new HeadingBlock(i, level, text));
                i++;
                continue;
            }

            // Horizontal Rule (---, ***, ___)
            if (IsHorizontalRule(line))
            {
                string marker = ExtractHrMarker(line);
                blocks.Add(new HorizontalRuleBlock(i, marker));
                i++;
                continue;
            }

            if (QuoteRegex.IsMatch(line))
            {
                int start = i;
                while (i < lines.Count && QuoteRegex.IsMatch(lines[i])) i++;
                blocks.Add(new QuoteBlock(start, i - 1));
                continue;
            }

            if (IsListLine(line))
            {
                int start = i;
                var listLines = new List<(int SourceLine, string Text)>();

                while (i < lines.Count && IsListLine(lines[i]))
                {
                    listLines.Add((i, lines[i]));
                    i++;
                }

                var items = ParseListItems(listLines);
                bool isOrderedTopLevel = AreAllTopLevelItemsOrdered(items);

                blocks.Add(new ListBlock(start, i - 1, items, isOrderedTopLevel));
                continue;
            }

            int pStart = i;
            while (i < lines.Count &&
                   !string.IsNullOrWhiteSpace(lines[i]) &&
                   !IsSpecialStart(lines, i))
            {
                i++;
            }

            if (i == pStart) i++;
            blocks.Add(new ParagraphBlock(pStart, i - 1));
        }

        return blocks;
    }

    private static bool IsListLine(string line)
        => ListLineRegex.IsMatch(line);

    private static List<ListItem> ParseListItems(IReadOnlyList<(int SourceLine, string Text)> listLines)
    {
        var result = new List<ListItem>(listLines.Count);

        // Stack enthält Indent-Werte, die die aktuelle Hierarchie repräsentieren.
        // Beispiel Indents: 0,2,4 => Levels 0,1,2
        var indentStack = new List<int>();

        foreach (var (sourceLine, raw) in listLines)
        {
            if (!TryParseListLine(raw, out var parsed))
                continue; // defensive; sollte wegen Vorfilter nicht passieren

            int indent = parsed.Indent;

            // Solange wir nicht tiefer sind, auf passende Parent-Ebene zurück.
            while (indentStack.Count > 0 && indent <= indentStack[^1])
                indentStack.RemoveAt(indentStack.Count - 1);

            int level = indentStack.Count;
            indentStack.Add(indent);

            result.Add(new ListItem(
                SourceLine: sourceLine,
                Indent: indent,
                Level: level,
                MarkerKind: parsed.MarkerKind,
                UnorderedMarker: parsed.UnorderedMarker,
                OrderedNumber: parsed.OrderedNumber,
                Text: parsed.Text));
        }

        return result;
    }

    private static bool AreAllTopLevelItemsOrdered(IReadOnlyList<ListItem> items)
    {
        bool hasTop = false;
        foreach (var it in items)
        {
            if (it.Level != 0) continue;
            hasTop = true;
            if (it.MarkerKind != ListMarkerKind.Ordered)
                return false;
        }

        return hasTop;
    }

    private readonly record struct ParsedListLine(
        int Indent,
        ListMarkerKind MarkerKind,
        char? UnorderedMarker,
        int? OrderedNumber,
        string Text);

    private static bool TryParseListLine(string line, out ParsedListLine parsed)
    {
        parsed = default;

        var m = ListLineRegex.Match(line);
        if (!m.Success) return false;

        string indentRaw = m.Groups["indent"].Value;
        int indent = NormalizeIndent(indentRaw);

        Group ul = m.Groups["ul"];
        Group num = m.Groups["num"];
        string text = m.Groups["text"].Value;

        if (ul.Success)
        {
            char marker = ul.Value[0];
            parsed = new ParsedListLine(
                Indent: indent,
                MarkerKind: ListMarkerKind.Unordered,
                UnorderedMarker: marker,
                OrderedNumber: null,
                Text: text);
            return true;
        }

        if (num.Success && int.TryParse(num.Value, out int n))
        {
            parsed = new ParsedListLine(
                Indent: indent,
                MarkerKind: ListMarkerKind.Ordered,
                UnorderedMarker: null,
                OrderedNumber: n,
                Text: text);
            return true;
        }

        return false;
    }

    // Tabs werden für Einrückung auf 4 Spaces normalisiert.
    private static int NormalizeIndent(string indent)
    {
        int count = 0;
        foreach (char ch in indent)
        {
            if (ch == '\t') count += 4;
            else if (ch == ' ') count++;
        }
        return count;
    }

    private static bool IsHorizontalRule(string line)
        => HorizontalRuleRegex.IsMatch(line);

    private static string ExtractHrMarker(string line)
    {
        foreach (char ch in line)
        {
            if (ch is '-' or '*' or '_')
                return ch.ToString();
        }

        // Fallback (sollte bei gültiger HR nicht auftreten)
        return "-";
    }

    private static bool HasFenceCloseAhead(IReadOnlyList<string> lines, int startIndex, char fenceChar, int minFenceLen)
    {
        for (int j = startIndex; j < lines.Count; j++)
        {
            if (IsFenceClose(lines[j], fenceChar, minFenceLen))
                return true;
        }

        return false;
    }

    private static bool TryParseFencedCode(IReadOnlyList<string> lines, ref int i, out CodeFenceBlock block)
    {
        block = null!;

        if (i < 0 || i >= lines.Count) return false;

        var m = FenceStartRegex.Match(lines[i]);
        if (!m.Success) return false;

        string fenceToken = m.Groups[1].Value;   // ``` oder ~~~ (auch länger)
        string language = m.Groups[2].Value.Trim();

        char fenceChar = fenceToken[0];
        int minFenceLen = fenceToken.Length;

        int start = i;
        int close = -1;

        for (int j = i + 1; j < lines.Count; j++)
        {
            if (IsFenceClose(lines[j], fenceChar, minFenceLen))
            {
                close = j;
                break;
            }
        }

        // Editor-friendly:
        // Unclosed fence => NICHT als CodeFenceBlock parsen.
        if (close < 0)
            return false;

        block = new CodeFenceBlock(start, close, fenceToken, language);
        i = close + 1;
        return true;
    }

    private static bool IsFenceClose(string line, char fenceChar, int minFenceLen)
    {
        int i = 0;

        // Markdown: bis zu 3 führende Spaces erlauben
        int leadingSpaces = 0;
        while (i < line.Length && line[i] == ' ' && leadingSpaces < 3)
        {
            i++;
            leadingSpaces++;
        }

        // Danach muss direkt die Fence beginnen
        int count = 0;
        while (i < line.Length && line[i] == fenceChar)
        {
            count++;
            i++;
        }

        if (count < minFenceLen) return false;

        // Danach nur noch Whitespace
        while (i < line.Length)
        {
            if (!char.IsWhiteSpace(line[i])) return false;
            i++;
        }

        return true;
    }

    // ---------- TABLES (strict) ----------

    private static bool IsPotentialTableStart(IReadOnlyList<string> lines, int i)
    {
        if (i + 1 >= lines.Count) return false;

        return TryParseTableHeaderAndDelimiter(
            lines[i],
            lines[i + 1],
            out _,
            out _);
    }

    private static bool TryParseTable(IReadOnlyList<string> lines, ref int i, out TableBlock block)
    {
        block = null!;

        if (i + 1 >= lines.Count) return false;

        string headerLine = lines[i];
        string delimiterLine = lines[i + 1];

        if (!TryParseTableHeaderAndDelimiter(headerLine, delimiterLine, out var headerCells, out var alignments))
            return false;

        int expectedCols = headerCells.Count;

        var rows = new List<TableRow>
        {
            new(i, headerCells)
        };

        int j = i + 2;
        while (j < lines.Count && IsLikelyTableBodyRow(lines[j], expectedCols))
        {
            rows.Add(new TableRow(j, ParseTableCells(lines[j])));
            j++;
        }

        // enthält mindestens Header + Delimiter
        int end = Math.Max(i + 1, j - 1);

        block = new TableBlock(i, end, rows, alignments);
        i = j;
        return true;
    }

    private static bool TryParseTableHeaderAndDelimiter(
        string headerLine,
        string delimiterLine,
        out List<string> headerCells,
        out List<TableAlignment> alignments)
    {
        headerCells = ParseTableCells(headerLine);
        alignments = new List<TableAlignment>();

        // Für Editor-UX: min. 2 Spalten
        if (headerCells.Count < 2) return false;

        // Strikt: beide Zeilen müssen echt table-like sein
        if (!IsPipeBounded(headerLine) || !IsPipeBounded(delimiterLine))
            return false;

        var delimiterCells = ParseTableCells(delimiterLine);

        if (delimiterCells.Count != headerCells.Count)
            return false;

        foreach (string raw in delimiterCells)
        {
            string cell = raw.Trim();

            if (!TableDelimiterCellRegex.IsMatch(cell))
                return false;

            bool left = cell.StartsWith(":");
            bool right = cell.EndsWith(":");

            if (left && right) alignments.Add(TableAlignment.Center);
            else if (left) alignments.Add(TableAlignment.Left);
            else if (right) alignments.Add(TableAlignment.Right);
            else alignments.Add(TableAlignment.None);
        }

        return true;
    }

    private static bool IsLikelyTableBodyRow(string line, int expectedCols)
    {
        if (string.IsNullOrWhiteSpace(line)) return false;
        if (!IsPipeBounded(line)) return false;

        var cells = ParseTableCells(line);
        return cells.Count == expectedCols;
    }

    private static bool IsPipeBounded(string line)
    {
        string s = line.Trim();
        return s.StartsWith("|", StringComparison.Ordinal) && s.EndsWith("|", StringComparison.Ordinal);
    }

    private static bool IsSpecialStart(IReadOnlyList<string> lines, int i)
    {
        string line = lines[i];

        if (string.IsNullOrWhiteSpace(line)) return true;
        if (HeadingRegex.IsMatch(line)) return true;
        if (IsHorizontalRule(line)) return true;
        if (QuoteRegex.IsMatch(line)) return true;
        if (IsListLine(line)) return true;
        if (IsPotentialTableStart(lines, i)) return true;

        // Fence nur dann special, wenn später ein Ende existiert.
        var m = FenceStartRegex.Match(line);
        if (m.Success)
        {
            string token = m.Groups[1].Value;
            char fenceChar = token[0];
            int minFenceLen = token.Length;

            if (HasFenceCloseAhead(lines, i + 1, fenceChar, minFenceLen))
                return true;
        }

        return false;
    }

    // Splittet Zellen und unterstützt escaped pipes "\|"
    private static List<string> ParseTableCells(string line)
    {
        string s = line.Trim();

        if (s.StartsWith("|", StringComparison.Ordinal)) s = s[1..];
        if (s.EndsWith("|", StringComparison.Ordinal)) s = s[..^1];

        var cells = new List<string>();
        var sb = new StringBuilder();

        for (int i = 0; i < s.Length; i++)
        {
            char ch = s[i];

            // escaped pipe: \|
            if (ch == '\\' && i + 1 < s.Length && s[i + 1] == '|')
            {
                sb.Append('|');
                i++;
                continue;
            }

            if (ch == '|')
            {
                cells.Add(sb.ToString().Trim());
                sb.Clear();
                continue;
            }

            sb.Append(ch);
        }

        cells.Add(sb.ToString().Trim());
        return cells;
    }
}
